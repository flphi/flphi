from app import *
from classes import *
from flask_cors import cross_origin

# Info de tous les comptes utilisteurs, ADMIN
@app.route('/user', methods=['GET'])
def get_all_users():
	users = User.query.all()
	output = []

	for user in users:
		user_data = {}
		user_data['public_id'] = str(user.public_id)
		user_data['name'] = str(user.name)
		user_data['password'] = str(user.password)
		user_data['super_user'] = user.super_user
		user_data['email'] = str(user.email)
		user_data['token'] = str(user.token)
		output.append(user_data)

	return {'users' : output}

# get current_user
@app.route('/current_user', methods=['GET'])
@cross_origin()
def current_user():
	token_h = request.headers['x-access-token']
	user = User.query.filter_by(token=token_h).first()
	if not user:
		return {'message':'No user found!'}

	user_data = {}
	user_data['public_id'] = str(user.public_id)
	user_data['name'] = str(user.name)
	user_data['password'] = str(user.password)
	user_data['super_user'] = user.super_user
	user_data['email'] = str(user.email)
	user_data['token'] = str(user.token)
	return {'user':user_data}

## Info d'un utilisateur, ADMIN
@app.route('/user/<public_id>', methods=['GET'])
@cross_origin()
@token_required
def get_one_user(current_user, public_id):

	if not current_user.super_user:
		return {'message': 'You can not perform that function!'}

	user = User.query.filter_by(public_id = public_id).first()
	if not user:
		return {'message':'No user found!'}

	user_data = {}
	user_data['public_id'] = user.public_id
	user_data['name'] = user.name
	user_data['password'] = user.password
	user_data['super_user'] = user.super_user
	user_data['email'] = user.email
	return {'user':user_data}

## Creer des profils utilisateurs, ADMIN
@app.route('/user', methods=['POST'])
@cross_origin()
@token_required
def create_user(current_user):

	if not current_user.super_user:
		return {'message': 'You can not perform that function!'}

	form = request.json
	username = form['username']
	pw = form['password']
	email = form['email']
	hashed_password = generate_password_hash(pw, method='sha256')
	new_user = User(public_id=str(uuid.uuid4()), name = username, password=hashed_password, super_user=False, email=email)
	db.session.add(new_user)
	db.session.commit()
	return {'message' : 'New user created'}

## Promotion du compte utilisateur en compte admin, ADMIN
@app.route('/user/<public_id>', methods=['PUT'])
@cross_origin()
@token_required
def promote_user(current_user, public_id):

	if not current_user.super_user:
		return {'message': 'You can not perform that function!'}

	user = User.query.filter_by(public_id = public_id).first()
	if not user:
		return {'message':'No user found!'}

	user.super_user = request.json['super_user']
	db.session.commit()
	if(request.json['super_user']):
		return {'message':'The user has been promoted.'}
	return {'message':'The user has been downgraded.'}

## Supprime des comptes utilisateurs, ADMIN
@app.route('/user/<public_id>', methods=['DELETE'])
@cross_origin()
@token_required
def delete_user(current_user, public_id):

	if not current_user.super_user:
		return {'message': 'You can not perform that function!'}
		
	user = User.query.filter_by(public_id = public_id).first()
	if not user:
		return {'message':'No user found!'}

	db.session.delete(user)
	db.session.commit()
	return {'message':'The user has been deleted.'}

## Change email
@app.route('/user/email/<public_id>', methods=['PUT'])
@cross_origin()
def change_user_email(public_id):
	user = User.query.filter_by(public_id = public_id).first()
	if not user:
		return {'message':'No user found!'}

	user.email = request.json['new_email']
	db.session.commit()
	return {'message':'Email is changed.'}

## Change email
@app.route('/user/pw/<public_id>', methods=['PUT'])
@cross_origin()
def change_user_pw(public_id):

	user = User.query.filter_by(public_id = public_id).first()
	if not user:
		return {'message':'No user found!'}

	hashed_password = generate_password_hash(request.json['new_pw'], method='sha256')
	user.password = hashed_password
	db.session.commit()
	return {'message':'Password changed.'}

## Pour se connecter
@app.route('/login', methods=['POST'])
@cross_origin()
def login():
	body = request.json
	username = body['username']
	pw = body['password']

	if not username or not pw:
		return make_response('Could not verify', 401, {'WWW-Authenticate' : 'Basic realm="Login required!"'})

	user = User.query.filter_by(name=username).first()

	if not user:
		return make_response('Could not verify', 401, {'WWW-Authenticate' : 'Basic realm="Login required!"'})

	if check_password_hash(user.password, pw):
		token = jwt.encode({'public_id': user.public_id, 'exp': datetime.utcnow() + timedelta(minutes=30)}, app.config['SECRET_KEY'])
		user.token = token.decode()
		db.session.commit()
		return {'token': token.decode('UTF-8')}

	return make_response('Could not verify', 401, {'WWW-Authenticate' : 'Basic realm="Login required!"'})

@app.route('/send/mail', methods=['POST'])
@cross_origin()
@token_required
def send_mail(current_user):

	if not current_user.super_user:
		return {'message': 'You can not perform that function!'}

	users = User.query.all()
	emails = []
	for user in users:
		emails.append(user.email)

	mail = Mail(app)

	msg = Message(request.json['title'], sender="projbacc@gmail.com", recipients=emails)
	msg.body = request.json['content']
	mail.send(msg)

	return 'Messages have been sent.'