from flask import Flask, render_template, request, redirect, make_response
from flask_sqlalchemy import SQLAlchemy
from geoalchemy2 import Geography, functions
from geoalchemy2.shape import to_shape 
from datetime import datetime, timedelta
import uuid
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
from functools import wraps
from flask_cors import CORS
from flask_mail import Mail, Message

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

app.config.from_pyfile('config.py')

db = SQLAlchemy(app)
mail = Mail(app)

from views import *
from views_auth import *

if __name__ == "__main__":
	app.run(debug=True)