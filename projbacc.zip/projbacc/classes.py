from app import *

## Classe pour l'authentification ##
class User(db.Model):
	id = db.Column(db.Integer, primary_key=True)
	public_id = db.Column(db.String(50), unique=True)
	name = db.Column(db.String(50))
	password = db.Column(db.String(80))
	super_user = db.Column(db.Boolean)
	token = db.Column(db.String(255))
	email = db.Column(db.String(255))

def token_required(f):
	@wraps(f)
	def decorated(*args, **kwargs):
		token = None
		if 'x-access-token' in request.headers:
			token = request.headers['x-access-token']
		if not token:
			return {'message': 'Token is missing.'}, 401
		try:
			data = jwt.decode(token, app.config['SECRET_KEY'])
			current_user = User.query.filter_by(public_id=data['public_id']).first()
			if current_user.token != token:
				return {'message': 'Token is invalid.'}, 401
		except:
			return {'message': 'Token is invalid.'}, 401
		return f(current_user, *args, **kwargs)
	return decorated

## Classe de postgresql
class Organismes(db.Model):
	__bind_key__ = 'postgis'
	__tablename__ = 'organismes'
	id_organisme = db.Column(db.Integer, primary_key=True)
	nom = db.Column(db.String(100))
	nom_abr = db.Column(db.String(10))
	url = db.Column(db.Text)
	telephone = db.Column(db.String(20))
	adresse_postale = db.Column(db.Text)
	courriel = db.Column(db.Text)

	def __init__(self, id_organisme, nom, nom_abr, url, telephone, adresse_postale, courriel):
	    self.id_organisme = id_organisme
	    self.nom = nom
	    self.nom_abr = nom_abr
	    self.url = url
	    self.telephone = telephone
	    self.adresse_postale = adresse_postale
	    self.courriel = courriel

class Sources(db.Model):
	__bind_key__ = 'postgis'
	__tablename__ = 'sources'
	id_source = db.Column(db.Integer, primary_key=True)
	id_organisme = db.Column(db.Integer)
	type_diffusion = db.Column(db.Text)
	url_donnees = db.Column(db.Text)
	url_metadonnees = db.Column(db.Text)
	appareil_mesure = db.Column(db.Text)
	type_mesure = db.Column(db.Text)
	frequence_maj = db.Column(db.String(255))

	def __init__(self, id_source, id_organisme, type_diffusion, url_donnees, url_metadonnees, appareil_mesure, type_mesure, frequence_maj):
		self.id_source = id_source
		self.id_organisme = id_organisme
		self.type_diffusion = type_diffusion
		self.url_donnees = url_donnees
		self.url_metadonnees = url_metadonnees
		self.appareil_mesure = appareil_mesure
		self.type_mesure = type_mesure
		self.frequence_maj = str(timedelta(**frequence_maj.hour))

class Variables_meteos(db.Model):
	__bind_key__ = 'postgis'
	__tablename__ = 'variables_meteos'
	id_variable = db.Column(db.Integer, primary_key=True)
	id_source = db.Column(db.Integer)
	nom = db.Column(db.Text)
	type_donnees = db.Column(db.Text)
	unites = db.Column(db.String(20))
	description = db.Column(db.Text)
	duree_valide = db.Column(db.DateTime)

	def __init__(self, id_variable, id_source, nom, type_donnees, unites, description, duree_valide):
		self.id_variable = id_variable
		self.id_source = id_source
		self.nom = nom
		self.type_donnees = type_donnees
		self.unites = unites
		self.description = description
		self.duree_valide = duree_valide

class Villages(db.Model):
	__bind_key__ = 'postgis'
	__tablename__ = 'villages'
	id_village = db.Column(db.Integer, primary_key=True)
	nom = db.Column(db.String(50))
	geom = db.Column(Geography(geometry_type='POLYGON', srid='4326'))

	def __init__(self, id_village, nom, geom):
		self.id_village = id_village
		self.nom = nom
		self.geom = geom

class Positions(db.Model):
	__bind_key__ = 'postgis'
	__tablename__ = 'positions'
	id_position = db.Column(db.Integer, primary_key=True)
	geom = db.Column(Geography(geometry_type='POINT', srid='4326'))

	def __init__(self, id_position, geom):
		self.id_position = id_position
		self.geom = geom

class Stations(db.Model):
	__bind_key__ = 'postgis'
	__tablename__ = 'stations'
	id_station = db.Column(db.Integer, primary_key=True)
	id_organisme = db.Column(db.Integer)
	nom_station = db.Column(db.String(100))
	description = db.Column(db.Text)
	geom = db.Column(Geography(geometry_type='POINT', srid='4326'))


	def __init__(self, id_station, id_organisme, nom_station, description, geom):
		self.id_station = id_station
		self.id_organisme = id_organisme
		self.nom_station = nom_station
		self.description = description
		self.geom = geom

class Donnees(db.Model):
	__bind_key__ = 'postgis'
	__tablename__ = 'donnees'
	id_variable = db.Column(db.Integer, primary_key=True)
	id_station = db.Column(db.Integer)
	id_position = db.Column(db.Integer)
	valeur = db.Column(db.Float)
	date_enr = db.Column(db.DateTime)
	date_valide_debut = db.Column(db.DateTime)

	def __init__(self, id_variable, id_station, id_position, valeur, date_enr, date_valide_debut):
		self.id_variable = id_variable
		self.id_station = id_station
		self.id_position = id_position
		self.valeur = valeur
		self.date_enr = date_enr
		self.date_valide_debut = date_valide_debut

class Indicateurs(db.Model):
	__bind_key__ = 'postgis'
	__tablename__ = 'indicateurs'
	id_indicateur = db.Column(db.Integer, primary_key=True)
	evenement_meteo = db.Column(db.String(100))
	desc_evenement = db.Column(db.Text)
	desc_calcul = db.Column(db.Text)
	repertoire_script = db.Column(db.Text)

	def __init__(self, id_indicateur, evenement_meteo, desc_evenement, desc_calcul, repertoire_script):
		self.id_indicateur = id_indicateur
		self.evenement_meteo = evenement_meteo
		self.desc_evenement = desc_evenement
		self.desc_calcul = desc_calcul
		self.repertoire_script = repertoire_script

class Valeurs_indicateurs(db.Model):
	__bind_key__ = 'postgis'
	__tablename__ = 'valeurs_indicateurs'
	id_position = db.Column(db.Integer, primary_key=True)
	id_indicateur = db.Column(db.Integer, primary_key=True)
	valeur = db.Column(db.Float, nullable=False)

	def __init__(self, id_position, id_indicateur, valeur):
		self.id_position = id_position
		self.id_indicateur = id_indicateur
		self.valeur = valeur

class Donnees_images(db.Model):
	__bind_key__ = 'postgis'
	__tablename__ = 'donnees_images'
	id_image = db.Column(db.Integer, primary_key=True)
	id_source = db.Column(db.Integer)
	repertoire_stockage = db.Column(db.Text)
	date_image = db.Column(db.DateTime)
	date_enr = db.Column(db.DateTime)
	resolution_m = db.Column(db.Float)
	nb_pixels_largeur = db.Column(db.Integer)
	nb_pixels_hauteur = db.Column(db.Integer)
	ennuagement_pour100 = db.Column(db.Float)

	def __init__(self, id_image, id_source, repertoire_stockage, date_image, date_enr, resolution_m, nb_pixels_largeur, nb_pixels_hauteur, ennuagement_pour100):
		self.id_image = id_image
		self.id_source = id_source
		self.repertoire_stockage = nom
		self.date_image = date_image
		self.date_enr = date_enr
		self.resolution_m = resolution_m
		self.nb_pixels_largeur = nb_pixels_largeur
		self.nb_pixels_hauteur = nb_pixels_hauteur
		self.ennuagement_pour100 = ennuagement_pour100
