from app import *
from classes import *

from flask_cors import cross_origin

@app.route('/')
@cross_origin()
def hello():
	return "Hello world"

## Retourne les organismes
@app.route('/organismes', methods=['GET'])
def get_organismes():

	organismes = Organismes.query.all()
	output = []
	for orga in organismes:
		orga_data = {}
		orga_data['nom'] = orga.nom
		orga_data['nom_abr'] = orga.nom_abr
		orga_data['url'] = orga.url
		orga_data['adresse_postale'] = orga.adresse_postale
		orga_data['courriel'] = orga.courriel
		output.append(orga_data)

	return {'Organismes': output}

## Retourne les sources
@app.route('/sources', methods=['GET'])
def get_sources():

	sources = Sources.query.all()
	output = []
	for source in sources:
		source_data = {}
		source_data['id_source'] = source.id_source
		source_data['id_organisme'] = source.id_organisme
		source_data['type_diffusion'] = source.type_diffusion
		source_data['url_donnees'] = source.url_donnees
		source_data['url_metadonnees'] = source.url_metadonnees
		source_data['appareil_mesure'] = source.appareil_mesure
		source_data['type_mesure'] = source.type_mesure
		source_data['frequence_maj'] = str(source.frequence_maj)
		
		output.append(source_data)

	return {'Sources': output} 

## Retourne les variables meteos
@app.route('/variables_meteos', methods=['GET'])
def get_variables_meteos():

	variables = Variables_meteos.query.all()
	output = []
	for var in variables:
		var_data = {}
		var_data['id_variable'] = var.id_variable
		var_data['id_source'] = var.id_source
		var_data['nom'] = var.nom
		var_data['type_donnees'] = var.type_donnees
		var_data['unites'] = var.unites
		var_data['description'] = var.description
		var_data['duree_valide'] = str(var.duree_valide)
		
		output.append(var_data)

	return {'Variables_meteos': output}

## Retourne les villages
@app.route('/villages', methods=['GET'])
def get_villages():

	villages = Villages.query.all()
	output = []
	for village in villages:
		village_data = {}
		village_data['id_village'] = village.id_village
		village_data['nom'] = village.nom
		village_data['geom'] = str(village.geom)
		village_data['geom_WKT'] = str(to_shape(village.geom).to_wkt())
		
		output.append(village_data)

	return {'Villages': output}

## Retourne les positions
@app.route('/positions', methods=['GET'])
def get_positions():

	positions = Positions.query.all()
	output = []
	for pos in positions:
		pos_data = {}
		pos_data['id_position'] = pos.id_position
		pos_data['geom'] = str(pos.geom)
		pos_data['geom_WKT'] = str(to_shape(pos.geom).to_wkt())
		
		output.append(pos_data)

	return {'Positions': output}

## Retourne les stations
@app.route('/stations', methods=['GET'])
def get_stations():

	stations = Stations.query.all()
	output = []
	for station in stations:
		sta_data = {}
		sta_data['id_station'] = station.id_station
		sta_data['id_organisme'] = station.id_organisme
		sta_data['nom_station'] = station.nom_station
		sta_data['description'] = station.description
		sta_data['geom'] = str(station.geom)
		sta_data['geom_WKT'] = str(to_shape(station.geom).to_wkt())
		
		output.append(sta_data)

	return {'Stations': output}

## Retourne les donnees
@app.route('/donnees', methods=['GET'])
def get_donnees():

	donnees = Donnees.query.all()
	output = []
	for donnee in donnees:
		data = {}
		data['id_variable'] = donnee.id_variable
		data['id_station'] = donnee.id_station
		data['id_position'] = donnee.id_position
		data['valeur'] = donnee.valeur
		data['date_enr'] = donnee.date_enr
		data['date_valide_debut'] = donnee.date_valide_debut
		
		output.append(data)

	return {'Donnees': output}

## Retourne les indicateurs
@app.route('/indicateurs', methods=['GET'])
def get_indicateurs():

	indicateurs = Indicateurs.query.all()
	output = []
	for indic in indicateurs:
		indic_data = {}
		indic_data['id_indicateur'] = indic.id_indicateur
		indic_data['evenement_meteo'] = indic.evenement_meteo
		indic_data['desc_evenement'] = indic.desc_evenement
		indic_data['desc_calcul'] = indic.desc_calcul
		indic_data['repertoire_script'] = indic.repertoire_script
		
		output.append(indic_data)

	return {'Indicateurs': output}

## Retourne les valeurs d'indicateurs
@app.route('/data/indicateurs', methods=['GET'])
def get_data_indicateurs():

	datas = Valeurs_indicateurs.query.all()
	output = []
	for data in datas:
		dataX = {}
		dataX['id_position'] = data.id_position
		dataX['id_indicateur'] = data.id_indicateur
		dataX['valeur'] = data.valeur
		
		output.append(data)

	return {'Valeurs_indicateurs': output}

## Retourne les data d'image
@app.route('/data/image', methods=['GET'])
def get_image_data():

	datas = Donnees_images.query.all()
	output = []
	for data in datas:
		dataX = {}
		dataX['id_image'] = data.id_image
		dataX['id_source'] = data.id_source
		dataX['repertoire_stockage'] = data.repertoire_stockage
		dataX['date_image'] = data.date_image
		dataX['date_enr'] = data.date_enr
		dataX['resolution_m'] = data.resolution_m
		dataX['nb_pixels_largeur'] = data.nb_pixels_largeur
		dataX['nb_pixels_hauteur'] = data.nb_pixels_hauteur
		dataX['ennuagement_pour100'] = data.ennuagement_pour100
		
		output.append(data)

	return {'Donnees_images': output}